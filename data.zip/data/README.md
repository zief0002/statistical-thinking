Data
=========

These are the data sets used in the EPsy 3264 course, _Basic and Applied Statistics_ taught at the University of Minnesota. 

[http://zief0002.github.io/statistical-thinking/](http://zief0002.github.io/statistical-thinking/)